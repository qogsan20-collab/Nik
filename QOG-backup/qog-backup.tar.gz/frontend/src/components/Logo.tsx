import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="logo-text" aria-label="Qog logo">qog</div>
  );
};

export default Logo;





